Cognifyz Level 1 - Task 1
HTML Structure and Basic Server Interaction

Files:
- index.html: Form structure
- style.css: Responsive styling
- script.js: Form validation and fetch request
- server.js: Express server and POST endpoint
- package.json: Node project configuration

Run:
1. Install Node.js.
2. Open this folder in VS Code.
3. Run: npm install
4. Run: npm start
5. Open: http://localhost:3000

The form sends its data to the Express POST /submit endpoint.
The server returns the submitted name and email as JSON.
No database is configured, so submissions are not stored.
