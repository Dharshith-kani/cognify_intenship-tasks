const express = require("express");
const path = require("path");

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname)));

app.post("/submit", (req, res) => {
  const { name, email } = req.body;

  if (typeof name !== "string" || typeof email !== "string" ||
      !name.trim() || !email.trim()) {
    return res.status(400).json({ message: "Name and email are required." });
  }

  // Respond with submitted values; no database is used.
  res.json({
    name: name.trim(),
    email: email.trim()
  });
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
