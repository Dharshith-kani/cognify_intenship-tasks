const form = document.querySelector("#userForm");
const result = document.querySelector("#result");

form.addEventListener("submit", async (event) => {
  event.preventDefault();

  const submitButton = form.querySelector("button");
  const formData = new FormData(form);
  const user = {
    name: formData.get("name").trim(),
    email: formData.get("email").trim()
  };

  if (!user.name || !user.email) {
    return;
  }

  submitButton.disabled = true;
  submitButton.textContent = "Submitting...";

  try {
    // Sends the form to the Express server.
    const response = await fetch("/submit", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(user)
    });

    if (!response.ok) {
      throw new Error("The server could not process the submission.");
    }

    const data = await response.json();

    // Use textContent to display user input safely.
    result.replaceChildren();

    const heading = document.createElement("h2");
    heading.textContent = "Form Submitted Successfully!";

    const greeting = document.createElement("p");
    greeting.textContent = `Welcome, ${data.name}.`;

    const email = document.createElement("p");
    email.textContent = `Your email address is: ${data.email}`;

    result.append(heading, greeting, email);
    result.hidden = false;
  } catch (error) {
    result.textContent = "Unable to submit the form. Make sure the Express server is running.";
    result.hidden = false;
    result.style.background = "#fff1f1";
    result.style.color = "#a12626";
  } finally {
    submitButton.disabled = false;
    submitButton.textContent = "Submit Details";
  }
});
